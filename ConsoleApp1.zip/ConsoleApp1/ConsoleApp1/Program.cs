﻿using System;
using System.Net.Sockets;
using System.Text;

namespace WhoisSorgu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Web sitesinin alan adını girin: ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            string domain = Console.ReadLine();
            Console.ResetColor();

            if (domain.ToLower() == "ixbir.net")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Bu domainin sorgulamasına izin verilmiyor!");
                Console.ResetColor();
                Console.ReadKey();
                return;
            }

            if (domain.ToLower() == "yougamearea.com")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Bu domainin sorgulamasına izin verilmiyor!");
                Console.ResetColor();
                Console.ReadKey();
                return;
            }

            string whoisServer = GetWhoisServer(domain);
            if (string.IsNullOrEmpty(whoisServer))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Geçersiz domain!");
                Console.ResetColor();
                Console.ReadKey();
                return;
            }

            string whoisResponse = SendWhoisQuery(domain, whoisServer);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("WHOIS Sorgusu Sonucu:");
            Console.WriteLine("------------------------");
            Console.ResetColor();
            Console.WriteLine(whoisResponse);

            Console.ReadKey();
        }

        static string GetWhoisServer(string domain)
        {
            string whoisServer = string.Empty;

            try
            {
                string whoisRequest = $"-h whois.iana.org {domain}";
                string whoisResponse = SendWhoisQuery(domain, "whois.iana.org");

                int start = whoisResponse.IndexOf("whois:");
                int end = whoisResponse.IndexOf("\n", start);

                if (start >= 0 && end >= 0)
                {
                    whoisServer = whoisResponse.Substring(start, end - start).Replace("whois:", "").Trim();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Whois sunucusu bulunamadı: " + ex.Message);
            }

            return whoisServer;
        }

        static string SendWhoisQuery(string domain, string whoisServer)
        {
            StringBuilder response = new StringBuilder();

            try
            {
                using (TcpClient tcpClient = new TcpClient(whoisServer, 43))
                {
                    using (NetworkStream networkStream = tcpClient.GetStream())
                    {
                        byte[] queryBytes = Encoding.ASCII.GetBytes(domain + "\r\n");
                        networkStream.Write(queryBytes, 0, queryBytes.Length);

                        byte[] buffer = new byte[4096];
                        int bytesRead = networkStream.Read(buffer, 0, buffer.Length);
                        while (bytesRead > 0)
                        {
                            response.Append(Encoding.ASCII.GetString(buffer, 0, bytesRead));
                            bytesRead = networkStream.Read(buffer, 0, buffer.Length);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Whois sorgusu başarısız: " + ex.Message);
            }

            return response.ToString();
        }
    }
}
